console.log('Logging')
// document.addEventListener('contextmenu', e => e.preventDefault());


const crypt = (salt, text) => {
    var encryptedAES = CryptoJS.AES.encrypt(text, salt);
    return encryptedAES.toString();
    
  };
  
console.log(crypt("sdffg","fdfgdg"))


var port = String(5000);

function setPort(p) {   port = String(p); }

function setProperty(id,attrib,value){
    if(attrib == "text"){
        document.getElementById(id).innerText = value;
        }
    else if(attrib == "html"){
        document.getElementById(id).innerHTML = value;
    }
    else if(attrib == "value"){
        document.getElementById(id).value = value;
    }
        else{
            document.getElementById(id).setAttribute(attrib,value);
        }
}

function getProperty(ssid,id,attrib,key){
    if(attrib == "text"){
        let request = new XMLHttpRequest();
request.onreadystatechange = function () {
    if (this.readyState === 4) {
        if (this.status === 200) {
           
        } else if (this.response == null && this.status === 0) {
            document.body.className = 'error offline';
            console.log("The computer appears to be offline.");
        } else {
            document.body.className = 'error';
        }
    }
};
request.open("GET","http://127.0.0.1:"+port+"/?file="+ssid+"&msg="+crypt(key,document.getElementById(id).innerText), true);
request.send(null);
        
    }
    else if(attrib =="value"){
        let request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                if (this.status === 200) {
                   
                } else if (this.response == null && this.status === 0) {
                    document.body.className = 'error offline';
                    console.log("The computer appears to be offline.");
                } else {
                    document.body.className = 'error';
                }
            }
        };
        request.open("GET","http://127.0.0.1:"+port+"/?file="+ssid+"&msg="+crypt(key,document.getElementById(id).value), true);
        request.send(null);
    }
    else{
        let request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                if (this.status === 200) {
                 
                } else if (this.response == null && this.status === 0) {
                    document.body.className = 'error offline';
                    console.log("The computer appears to be offline.");
                } else {
                    document.body.className = 'error';
                }
            }
        };
        request.open("GET","http://127.0.0.1:"+port+"/?file="+ssid+"&msg="+crypt(key,document.getElementById(id).getAttribute(attrib)), true);
        request.send(null);
    }
}



function listener(ssid,id,event,ky){
    var folder = ssid
    console.log("listener called..");
    console.log(folder);
    i = 0;
    document.getElementById(id).addEventListener(event,(e)=>{
        console.log("called");
        var keys = [];
        var values = [];
        for (var k in e) keys.push(k);
        for (var k in e) values.push(e[k]);
        var towrite =String(keys)+"!!!!!!!!"+String(values);

        let request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                if (this.status === 200) {
                 
                } else if (this.response == null && this.status === 0) {
                    document.body.className = 'error offline';
                    console.log("The computer appears to be offline.");
                } else {
                    document.body.className = 'error';
                }
            }
        };
        request.open("GET","http://127.0.0.1:"+port+"/?file="+folder+"/"+ssid+String(i)+"&msg="+towrite, true);
        request.send(null);
        i++;


    });
}

function setcomp(html,divid){
    document.getElementById(divid).innerHTML = document.getElementById(divid).innerHTML+html;
}
function tablemoveup(rowid)
{
    jQuery("#"+rowid).prev().before(jQuery("#"+rowid));
}

function tablemovedown(rowid)
{
    jQuery("#"+rowid).prev().after(jQuery("#"+rowid));
}

function tabledelete(rowid)
{
    document.getElementById(rowid).parentNode.removeChild(document.getElementById(rowid));
}