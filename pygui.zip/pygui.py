import requests
import webview
import time
import signal
import shutil
from flaskconn import runmsgserver
import threading
import os
import random
from decrypt import *
import hashlib

def close():
    os.kill(os.getpid(),signal.SIGILL)




def ExitApp(exitcode=0):
    os.kill(os.getpid(),exitcode)

def get_md5(string):
        return hashlib.md5(string.encode()).hexdigest() # returns a str


app_list = []

def common_run():
    for i in app_list:
        th = threading.Thread(target=i)
        th.start()

def startapp(**kwargs):
    for x in kwargs.keys():
        app_list.append(kwargs[x])
    webview.start(common_run)


class pygui:
    def __init__(self):
        self.connect_port = 5000
        self.gui = ""
        self.title = "Python Pygui App"
        self.width = 800
        self.height = 600
        self.X = None
        self.Y = None
        self.resizeable = True
        self.Fullscreen = False
        self.min_size = (200, 100)
        self.hidden=False 
        self.frameless=False
        self.minimized=False 
        self.on_top=False 
        self.confirm_close=False 
        self.background_color='#FFF'
        self.text_select=False

    def close(self):
        self.this.destroy()
        os.kill(os.getpid(),0)
        shutil.rmtree("conn_temp")
        os.mkdir("conn_temp")

    def load_css(self,object,css=str):
        self.this.load_css(object+"{"+css+"}")



    def SetProperty(self,object=str, attrib=str, value=str):
        self.this.evaluate_js('setProperty("{}","{}","{}");'.format(object, attrib, value))

    def GetProperty(self,object=str,attrib=str):
        md5f=get_md5(str(time.time()))
        self.this.evaluate_js('getProperty("{}","{}","{}","{}");'.format(md5f,object, attrib,self.key))
        msg = requests.get(url ="http://127.0.0.1:"+str(self.port)+"/get?id="+md5f).text
        return(temp.decryptWithAES(msg.replace(" ","+"),self.key))
        
    
    def AddListener(self,object,event,function,arg=None):
            md5f=get_md5(str(time.time()))
            self.flist[md5f] = function
            self.arglist[md5f] = arg          
            self.this.evaluate_js('listener("{}","{}","{}","{}");'.format(md5f,object, event,self.key))
        
    def set_gui_port(self):
        self.this.evaluate_js('setPort('+str(self.port)+');')
    


    def create_app(self):
        self.key = get_md5(str(time.time()))+str(random.randint(0,6777777777789797))
        self.port = self.connect_port
        self.flist = {}
        self.arglist = {}
        x = threading.Thread(target=runmsgserver,args=(self.connect_port,self))
        x.start()
        window = webview.create_window(self.title, url=self.gui, width=self.width, height=self.height, \
                      x=self.X, y=self.Y, resizable=self.resizeable, fullscreen=self.Fullscreen, \
                      min_size=self.min_size, hidden=self.hidden, frameless=self.frameless, \
                      minimized=self.minimized, on_top=self.on_top, confirm_close=self.confirm_close, \
                      background_color=self.background_color, text_select=self.text_select)
        self.this = window
        
        # anything below this line will be executed after program is finished executing
        