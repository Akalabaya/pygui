from urllib.parse import urlparse
import webview
import time
import signal
import shutil
from flaskconn import runmsgserver
import threading
import os
import random
from decrypt import *
import hashlib

def on_closing():
        shutil.rmtree("conn_temp")
        os.mkdir("conn_temp")
        os.kill(os.getpid(),signal.SIGILL)

def ExitApp(exitcode=0):
    os.kill(os.getpid(),exitcode)

def get_md5(string):
        return hashlib.md5(string.encode()).hexdigest() # returns a str

def listener_controller(ssid,func,argv,key):
    files = os.listdir("conn_temp/"+ssid)
    while True:
        try:
            f2 = os.listdir("conn_temp/"+ssid)
        except:
            break
        new = set(f2).difference(files)
        if list(new) != []:
            for x in list(new):
                try:
                    c = open("conn_temp/"+ssid+"/"+x,"rb").read().decode().replace(" ","+").split("!!!!!!!!")
                    keys = c[0].split(",")
                    value = c[1].split(",")
                    d = {}
                    for y in range(0,len(keys)):
                        d[keys[y]] = value[y]
                    func(d,argv)
                except:
                    raise Exception("Error in processing function...")

        files = f2
        time.sleep(0.2)

            

class pygui:
    def __init__(self):
        self.connect_port = 5000
        self.gui = ""
        self.title = "Python Pygui App"
        self.width = 800
        self.height = 600
        self.X = None
        self.Y = None
        self.resizeable = True
        self.Fullscreen = False
        self.min_size = (200, 100)
        self.hidden=False 
        self.frameless=False
        self.minimized=False 
        self.on_top=False 
        self.confirm_close=False 
        self.background_color='#FFF'
        self.text_select=False

    def close(self):
        self.this.destroy()
        os.kill(os.getpid(),0)
        shutil.rmtree("conn_temp")
        os.mkdir("conn_temp")

    def load_css(self,object,css=str):
        self.this.load_css(object+"{"+css+"}")



    def SetProperty(self,object=str, attrib=str, value=str):
        self.this.evaluate_js('setProperty("{}","{}","{}");'.format(object, attrib, value))

    def GetProperty(self,object=str,attrib=str):
        md5f=get_md5(str(time.time()))
        self.this.evaluate_js('getProperty("{}","{}","{}","{}");'.format(md5f,object, attrib,self.key))
        while True:
            if os.path.exists("conn_temp/"+md5f):
                break
        return (temp.decryptWithAES(open("conn_temp/"+md5f,"rb").read().decode().replace(" ","+"),self.key))
        
    
    def AddListener(self,object,event,function,arg):
            md5f=get_md5(str(time.time()))
            os.mkdir("conn_temp/"+md5f)
            self.this.evaluate_js('listener("{}","{}","{}","{}");'.format(md5f,object, event,self.key))
            xt = threading.Thread(target=listener_controller,args=(md5f,function,arg,self.key))
            xt.start()
        
    def set_gui_port(self):
        self.this.evaluate_js('setPort('+str(self.port)+');')
    


    def create_app(self,func):
        self.key = get_md5(str(time.time()))+str(random.randint(0,6777777777789797))
        if not os.path.exists("conn_temp"):
            os.mkdir("conn_temp")
        self.port = self.connect_port
        x = threading.Thread(target=runmsgserver,args=(self.connect_port,))
        x.start()
        window = webview.create_window(self.title, url=self.gui, width=self.width, height=self.height, \
                      x=self.X, y=self.Y, resizable=self.resizeable, fullscreen=self.Fullscreen, \
                      min_size=self.min_size, hidden=self.hidden, frameless=self.frameless, \
                      minimized=self.minimized, on_top=self.on_top, confirm_close=self.confirm_close, \
                      background_color=self.background_color, text_select=self.text_select)
        self.this = window
        window.events.closed += on_closing
        webview.start(func)
        # anything below this line will be executed after program is finished executing
        x.join()