# Importing flask module in the project is mandatory
# An object of Flask class is our WSGI application.
from flask import Flask,request
from flask_cors import CORS
# Flask constructor takes the name of
# current module (__name__) as argument.
app = Flask(__name__)
CORS(app)
cors = CORS(app, resource={
    r"/*":{
        "origins":"*"
    }
})
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.FATAL)
data = {}
# The route() function of the Flask class is a decorator,
# which tells the application which URL should call
# the associated function.
@app.route('/')
# ‘/’ URL is bound with hello_world() function.
def write_get():
    page = request.args.get('file')
    filter = request.args.get('msg')
    data[page] = filter
    return 'Request Sent Successfully..'



@app.route('/listener')
# ‘/’ URL is bound with hello_world() function.
def run_listener():
    ssid = request.args.get('file')
   
    c = request.args.get('msg').replace(" ","+").split("!!!!!!!!")
    keys = c[0].split(",")
    value = c[1].split(",")
    d = {}
    for y in range(0,len(keys)):
        d[keys[y]] = value[y]
    globals()["obj"].flist[ssid](d,globals()["obj"].arglist[ssid])
    return 'Request Sent Successfully..'

@app.route('/get')

def get():
    i = 0
    p = ""
    while i < 10:
        i += 1
        try:
            page = request.args.get('id')
            p = data[page]
            break
        except:
            pass

    return p

# main driver function
def runmsgserver(port,obj):
    globals()["obj"] = obj
    # run() method of Flask class runs the application
    # on the local development server.
    app.run(port=port)

