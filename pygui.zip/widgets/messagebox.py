import win32api
import win32con
class MessageBox:
    def __init__(self):
        self.Ok = 0
        self.OkCancel = 1
        self.AbortRetryIgnore = 2
        self.YesNoCancel = 3
        self.type = 0
        self.icon = 0
    def setType(self,type):
        self.type = type
    def setIcon(self,icon):
        self.icon = icon
        
    def getResult(self,resultint):
        return {1:"Ok",2:"Cancel",3:"Abort",4:"Retry",5:"Ignore",6:"Yes",7:"No"}[resultint]

    def show(self,text=str,title=str,isontop=False):
        if isontop:
            return win32api.MessageBox(0,title,text,self.type | self.icon | win32con.MB_TOPMOST)
        else:
            return win32api.MessageBox(0,title,text,self.type | self.icon)

