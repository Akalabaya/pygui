
import time
import os
import threading
import hashlib


def get_md5(string):
        return hashlib.md5(string.encode()).hexdigest() # returns a str

def listener_controller(ssid,func,argv,key):
    files = os.listdir("conn_temp/"+ssid)
    while True:
        try:
            f2 = os.listdir("conn_temp/"+ssid)
        except:
            break
        new = set(f2).difference(files)
        if list(new) != []:
                x = list(new)[0]
                
                try:
                    c = open("conn_temp/"+ssid+"/"+x,"rb").read().decode().replace(" ","+").split("!!!!!!!!")
                    keys = c[0].split(",")
                    value = c[1].split(",")
                    d = {}
                    for y in range(0,len(keys)):
                        d[keys[y]] = value[y]
                    func(d,argv)
                except:
                    raise Exception("Error in processing function...")

        files = f2
        time.sleep(0.2)

class Component:
    def __init__(self,window,func,):
        self.app_ssid = [] 
        self.exp_func = func
        self.this = window.this
        self.obj = window
        self.key = window.key
    def add_component(self,divid,values):
        t = str(time.time())
        html = ""
        h = self.exp_func(t,values)
        for x in h.split("\n"):
            html += x
        self.app_ssid.append(t)
        self.this.evaluate_js('setcomp("'+html+'","'+divid+'");')
        return t


    def delete(self,ssid):
        self.this.evaluate_js('tabledelete("'+ssid+'");')

    def addListener(self,ssid,event,object,function,arg=[]):
        md5f = get_md5(ssid)+object
        try:
            os.mkdir("conn_temp/"+md5f)
        except:
            pass
        self.this.evaluate_js('listener("{}","{}","{}","{}");'.format(md5f,object+"_"+ssid, event,self.key))
        xt = threading.Thread(target=listener_controller,args=(md5f,function,arg,self.obj.key))
        xt.start()
        for x in self.app_ssid:
            if x != ssid:
                self.this.evaluate_js('listener("{}","{}","{}","{}");'.format(get_md5(x)+object,object+"_"+x, event,self.key))
                
        
    