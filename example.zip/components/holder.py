def export(ssid,value=[]):
    return """
    <thread>
             <tr id='t_"""+ssid+"""'>
                 <td id='l_"""+ssid+"""'>"""+value["fname"]+"""</td>
                 <td id='n_"""+ssid+"""' >"""+value["lname"]+"""</td>
                 <td id='en_"""+ssid+"""'>"""+value["email"]+"""</td>
                 <td>
                     <button id='e_"""+ssid+"""' class='btn btn-primary'>Edit</button>
                     <button id='d_"""+ssid+"""' class='btn btn-danger'>Delete</button>
                 </td>
             </tr>
             </thread>
    """