from pygui import pygui

app = pygui()


def main():
    print("About window shown...")
    app.SetProperty("text","text","Made by Akalabaya Pal")

def create():
    app.title = ("About the program")
    app.height = int(app.height / 2)
    app.gui = "Resources/about.html"
    app.minimized = True
    app.on_top = True
    app.width = int(app.width / 2)
    app.create_app()
    return [app,main]
