#Importing modules
from pygui import pygui,ExitApp
from widgets.component import Component
from components.holder import export
import pickle
import os
#Initalizing App 
app = pygui()


#class for our app
class Form1:
    def __init__(self):
        self.action = 0
        self.data = {}

    def edit(self,e,args):
        self.action = 1
        app.SetProperty("add","text","EDIT")
        self.sid = args

    def delete(self,e,args):
        self.c.delete("t_"+args)
        self.action = 0
        app.SetProperty("add","text","Add Account")
        self.data[args] = None

    def creating(self,e,args):
      if self.action == 0:
        Name = app.GetProperty("name","value")
        Email = app.GetProperty("email","value")
        if Name == "" or Email == "":
            args[0].evaluate_js("alert('Please fill the form');")
            app.SetProperty("name","value","")
            app.SetProperty("email","value","")
            return
        x = Name.split(" ")
        if len(x) <= 1:
            args[0].evaluate_js("alert('Please enter your last name');") 
            app.SetProperty("name","value","")
            app.SetProperty("email","value","")  
        else:
            s = self.c.add_component("holder",{"fname":x[0],"lname":x[1],"email":Email})
            app.SetProperty("name","value","")
            app.SetProperty("email","value","")
            self.c.addListener(s,"click","e",self.edit,s)
            self.c.addListener(s,"click","d",self.delete,s)
            self.save(Name,Email,s)
      elif self.action == 1:
          Name = app.GetProperty("name","value")
          Email = app.GetProperty("email","value")
          if Name == "" or Email == "":
            args[0].evaluate_js("alert('Please fill the form');")
            app.SetProperty("name","value","")
            app.SetProperty("email","value","")
            return
          
          x = Name.split(" ")
          if len(x) <= 1:
            args[0].evaluate_js("alert('Please enter your last name');") 
            app.SetProperty("name","value","")
            app.SetProperty("email","value","")  
          else:
              app.SetProperty("l_"+self.sid,"text",x[0])
              app.SetProperty("n_"+self.sid,"text",x[1])
              app.SetProperty("en_"+self.sid,"text",Email)
              app.SetProperty("add","text","ADD ACCOUNT")
              app.SetProperty("name","value","")
              app.SetProperty("email","value","")  
              self.action = 0
              self.save(Name,Email,self.sid)

    def save(self,name,email,ssid):
        self.data[ssid] = {"name": name, "email": email}
    def change(self,name,email,ssid):
        self.data[ssid] = {"name": name, "email": email}
    def closing(self):
        pickle.dump(self.data, open("data/data.pickle","wb"))
    def main(self):
        app.set_gui_port() #set the application port to our code listener
        app.this.events.closing += self.closing
        self.c = Component(app,export)
        if os.path.exists("data/data.pickle"):
            d = pickle.load(open("data/data.pickle","rb"))
            for x in d:
                if d[x] == None:
                    continue
                s = self.c.add_component("holder",{"fname":d[x]["name"].split(" ")[0],"lname":d[x]["name"].split(" ")[0],"email":d[x]["email"]})
                self.c.addListener(s,"click","e",self.edit,s)
                self.c.addListener(s,"click","d",self.delete,s)
                self.save(d[x]["name"],d[x]["email"],s)
        app.AddListener("add","click",self.creating,[app.this])



#creating App
app.title = "Account Manager"
app.connect_port = 9000
app.gui = "Resources/Form1.html"
app.confirm_close = True
app.create_app(Form1().main)

